﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormEmployee : Form
    {
        public FormEmployee()
        {
            InitializeComponent();
        }

        private void FormEmployee_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsEmployee.GetAllEmployees();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            FormAddEmployee formAddEmployee = new FormAddEmployee();
            formAddEmployee.ShowDialog();
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsEmployee.GetAllEmployees();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                if (ClsEmployee.DeleteEmployee(Convert.ToInt32(selectedRow.Cells[5].Value)))
                {
                    MessageBox.Show("Done");
                    dataGridView1.DataSource = ClsEmployee.GetAllEmployees();

                }
                else
                {
                    MessageBox.Show("Faild");


                }



            }
            else
            {
                MessageBox.Show("Please select a row first.");
            }


        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                FormUpateEmployee formUpateEmployee = new FormUpateEmployee(Convert.ToInt32(selectedRow.Cells[6].Value),
                  Convert.ToString(selectedRow.Cells[7].Value), Convert.ToInt32(selectedRow.Cells[8].Value), Convert.ToInt32(selectedRow.Cells[5].Value),
                  Convert.ToString(selectedRow.Cells[9].Value),
                  Convert.ToString(selectedRow.Cells[10].Value));
                  
                formUpateEmployee.ShowDialog();
                dataGridView1.DataSource = ClsEmployee.GetAllEmployees();


            }
            else
            {
                MessageBox.Show("Please select a row first.");
            }
           
        }
    }
}
