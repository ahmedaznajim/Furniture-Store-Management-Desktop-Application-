﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace furnitureStoreV2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text = "Welcome " + BusinessLayer.ClsUserNameAndPassword.UserName;
        }

        private void peopleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPeople formPeople = new FormPeople();
            formPeople.ShowDialog();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCustomer formCustomer = new FormCustomer();
            formCustomer.ShowDialog();
        }

        private void employeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEmployee formEmployee = new FormEmployee();
            formEmployee.ShowDialog();
        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormProduct formProduct = new FormProduct();
            formProduct.ShowDialog();
        }

        private void warehouseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormWarehouse formWarehouse = new FormWarehouse();
            formWarehouse.ShowDialog();
        }

        private void ordersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void placeAnOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPlaceOrder formPlaceOrder = new FormPlaceOrder();
            formPlaceOrder.ShowDialog();
        }

        private void showOrdersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOrders formOrders = new FormOrders();
            formOrders.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void signOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
            FormInterFace formInterFace = new FormInterFace();
            formInterFace.ShowDialog();
        }
    }
}
