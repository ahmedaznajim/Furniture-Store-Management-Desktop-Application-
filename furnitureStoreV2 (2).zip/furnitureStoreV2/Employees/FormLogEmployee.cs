﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormLogEmployee : Form
    {
        public FormLogEmployee()
        {
            InitializeComponent();
        }

        private void buttonLogIn_Click(object sender, EventArgs e)
        {
            if (ClsEmployee.CheckEmployeeLogInInfo(textBoxUserName.Text, textBoxPassword.Text))
            {
                ClsUserNameAndPassword.UserName = textBoxUserName.Text;
                ClsUserNameAndPassword.Password = textBoxPassword.Text;
                Form1 form1 = new Form1();
                this.Hide();
                form1.ShowDialog();


            }
            else
            {
                MessageBox.Show("The Passsword Or The User Name is Incorrect");


            }
        }

        private void Customers_Click(object sender, EventArgs e)
        {

        }

        private void textBoxPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
