﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;
using furnitureStoreV2.Product;

namespace furnitureStoreV2
{
    public partial class FormWarehouse : Form
    {
        public FormWarehouse()
        {
            InitializeComponent();
            dataGridView2.Visible = false;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            FormAddWarehouse formAddWarehouse = new FormAddWarehouse();
            formAddWarehouse.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormWarehouse_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsWarehouse.GetAllWarehouse();
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsWarehouse.GetAllWarehouse();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

            if (ClsWarehouse.DeleteWarehouse(Convert.ToInt32(selectedRow.Cells[0].Value)))
            {
                MessageBox.Show("Done");
                dataGridView1.DataSource = ClsWarehouse.GetAllWarehouse();

            }
            else
            {
                MessageBox.Show("Faild");
            }
        }

        private void showProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                dataGridView1.Visible = false;
                dataGridView2.Visible = true;
                dataGridView2.DataSource = ClsWarehouse.ShowProducts(Convert.ToInt32(selectedRow.Cells[0].Value));
            }
            catch
            {
                MessageBox.Show("No Row Selected");


            }
        }

        private void backToWarehousesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            dataGridView2.Visible = false;
            dataGridView1.DataSource = ClsWarehouse.GetAllWarehouse();
        }

        private void viewProductInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dataTable = ClsProduct.SerchID(Convert.ToInt32(dataGridView2.SelectedRows[0].Cells[0].Value));
                DataRow dataRow = dataTable.Rows[0];
                FormViewProductInfo formViewProductInfo = new FormViewProductInfo(Convert.ToInt32(dataRow[0])
                    , Convert.ToString(dataRow[1])
                    , Convert.ToInt32(dataRow[2])
                    , Convert.ToInt32(dataRow[3])
                    , Convert.ToInt32(dataRow[4])
                    , Convert.ToString(dataRow[5])


                    );
                formViewProductInfo.ShowDialog();
            }
            catch { }
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
