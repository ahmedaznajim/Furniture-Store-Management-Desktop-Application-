﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormCustomer : Form
    {
        public FormCustomer()
        {
            InitializeComponent();
            textBoxSerch.Enabled = false;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            FormCustomerAdd formCustomer = new FormCustomerAdd();
            formCustomer.ShowDialog();
            dataGridView1.DataSource = ClsCustmor.GetAllCustomers();
        }

        private void FormCustomer_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource=ClsCustmor.GetAllCustomers();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsCustmor.GetAllCustomers();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
              if(  ClsCustmor.DeleteCustomer( Convert.ToInt32(selectedRow.Cells[5].Value)))
                {
                    MessageBox.Show("Done");
                    dataGridView1.DataSource = ClsCustmor.GetAllCustomers();

                }
                else
                {
                    MessageBox.Show("Faild");


                }
              

                
            }
            else
            {
                MessageBox.Show("Please select a row first.");
            }



        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1 || comboBox1.SelectedIndex == 2|| comboBox1.SelectedIndex == 3)
            {
                textBoxSerch.Enabled = true;
            }
            if (comboBox1.SelectedIndex == 0)
            {
                textBoxSerch.Enabled = false;
                textBoxSerch.Text = "";
                dataGridView1.DataSource = ClsCustmor.GetAllCustomers();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                dataGridView1.DataSource = ClsCustmor.SerchID(
               Convert.ToInt32(textBoxSerch.Text));
            }

            if (comboBox1.SelectedIndex == 2)
            {
                dataGridView1.DataSource = ClsCustmor.SerchLastName(Convert.ToString(textBoxSerch.Text));
            }

            if (comboBox1.SelectedIndex == 3)
            {
                dataGridView1.DataSource = ClsCustmor.SerchUserName(Convert.ToString(textBoxSerch.Text));
            }
        }
    }
}
