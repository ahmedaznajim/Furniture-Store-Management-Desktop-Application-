﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormUpateEmployee : Form
    {
        int id;
        string postion;
        int salary;
        int EmployeeID;
        string EmployeeUserName;
        string EmployeePassword;

        public FormUpateEmployee(int id, string postion, int salary,int EmployeeID, string employeeUserName, string employeePassword)
        {
            InitializeComponent();
            this.id = id;
            this.postion = postion;
            this.salary = salary;
            this.EmployeeID = EmployeeID;
            this.EmployeeUserName = employeeUserName;
            this.EmployeePassword = employeePassword;

        }

        private void FormUpateEmployee_Load(object sender, EventArgs e)
        {
            textBoxID.Text = id.ToString();
            textBoxPosition.Text = postion.ToString();
            textBoxSalary.Text = salary.ToString();
            labelEmployeeID.Text = EmployeeID.ToString();
            textBoxUserName.Text = EmployeeUserName.ToString();
            textBoxPassword.Text = EmployeePassword.ToString();

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {

            if(ClsEmployee.UpdateEmployee(EmployeeID, postion, salary, EmployeeUserName, EmployeePassword))
            {
                MessageBox.Show("Done");

            }
            else
            {
                MessageBox.Show("Faild");

            }
        }

        private void groupBoxPersonInfo_Enter(object sender, EventArgs e)
        {

        }
    }
}
