﻿namespace furnitureStoreV2
{
    partial class FormShowProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonShowMyOrder = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelOrderId = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 54);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(759, 335);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // buttonShowMyOrder
            // 
            this.buttonShowMyOrder.Location = new System.Drawing.Point(12, 404);
            this.buttonShowMyOrder.Name = "buttonShowMyOrder";
            this.buttonShowMyOrder.Size = new System.Drawing.Size(166, 23);
            this.buttonShowMyOrder.TabIndex = 0;
            this.buttonShowMyOrder.Text = "Show My Order";
            this.buttonShowMyOrder.UseVisualStyleBackColor = true;
            this.buttonShowMyOrder.Click += new System.EventHandler(this.buttonShowMyOrder_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Order Id";
            // 
            // labelOrderId
            // 
            this.labelOrderId.AutoSize = true;
            this.labelOrderId.Location = new System.Drawing.Point(81, 9);
            this.labelOrderId.Name = "labelOrderId";
            this.labelOrderId.Size = new System.Drawing.Size(22, 13);
            this.labelOrderId.TabIndex = 2;
            this.labelOrderId.Text = "???";
            // 
            // FormShowProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelOrderId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonShowMyOrder);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "FormShowProducts";
            this.Text = "FormShowProducts";
            this.Load += new System.EventHandler(this.FormShowProducts_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button buttonShowMyOrder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelOrderId;
    }
}