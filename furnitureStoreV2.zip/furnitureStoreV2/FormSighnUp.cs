﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormSighnUp : Form
    {
        public FormSighnUp()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (ClsCustmor.SighnUP(textBoxFname.Text, textBoxLname.Text, textBoxEmail.Text, textBoxpNumber.Text, textBoxUserName.Text, textBoxPassword.Text) == -1)
            {
                MessageBox.Show("Faild");
            } else {
                MessageBox.Show("Done");
                this.Hide();

            }

        }
    }
}
