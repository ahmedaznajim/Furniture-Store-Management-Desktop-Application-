﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormInterfaceCustumer : Form
    {
        int CustumerId;

        public FormInterfaceCustumer(int custumerId)
        {
            InitializeComponent();
            CustumerId = custumerId;    
        }

        private void FormInterfaceCustumer_Load(object sender, EventArgs e)
        {
            labelCustomerID.Text=Convert.ToString(CustumerId);
        }

        private void buttonPlaceAnOrder_Click(object sender, EventArgs e)
        {

         int OrderID=   ClsOrder.AddNewOrder(CustumerId, DateTime.Now);
            FormShowProducts formShowProducts = new FormShowProducts(OrderID, CustumerId);
            formShowProducts.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonShowMyPreOrders_Click(object sender, EventArgs e)
        {
            FormShowPastOrders form=new FormShowPastOrders(CustumerId);
            form.ShowDialog();
        }
    }
}
