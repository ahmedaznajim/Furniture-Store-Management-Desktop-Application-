﻿namespace furnitureStoreV2
{
    partial class FormInterfaceCustumer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonPlaceAnOrder = new System.Windows.Forms.Button();
            this.buttonShowMyPreOrders = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelCustomerID = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonPlaceAnOrder
            // 
            this.buttonPlaceAnOrder.Font = new System.Drawing.Font("Tahoma", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPlaceAnOrder.Location = new System.Drawing.Point(134, 233);
            this.buttonPlaceAnOrder.Name = "buttonPlaceAnOrder";
            this.buttonPlaceAnOrder.Size = new System.Drawing.Size(548, 82);
            this.buttonPlaceAnOrder.TabIndex = 1;
            this.buttonPlaceAnOrder.Text = "Place an Order";
            this.buttonPlaceAnOrder.UseVisualStyleBackColor = true;
            this.buttonPlaceAnOrder.Click += new System.EventHandler(this.buttonPlaceAnOrder_Click);
            // 
            // buttonShowMyPreOrders
            // 
            this.buttonShowMyPreOrders.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowMyPreOrders.Location = new System.Drawing.Point(134, 321);
            this.buttonShowMyPreOrders.Name = "buttonShowMyPreOrders";
            this.buttonShowMyPreOrders.Size = new System.Drawing.Size(548, 82);
            this.buttonShowMyPreOrders.TabIndex = 3;
            this.buttonShowMyPreOrders.Text = "Show My Previous Orders";
            this.buttonShowMyPreOrders.UseVisualStyleBackColor = true;
            this.buttonShowMyPreOrders.Click += new System.EventHandler(this.buttonShowMyPreOrders_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Customer ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelCustomerID
            // 
            this.labelCustomerID.AutoSize = true;
            this.labelCustomerID.Location = new System.Drawing.Point(90, 12);
            this.labelCustomerID.Name = "labelCustomerID";
            this.labelCustomerID.Size = new System.Drawing.Size(35, 13);
            this.labelCustomerID.TabIndex = 6;
            this.labelCustomerID.Text = "label2";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::furnitureStoreV2.Properties.Resources.product__1_;
            this.pictureBox3.Location = new System.Drawing.Point(20, 321);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(108, 82);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::furnitureStoreV2.Properties.Resources.delivery_box;
            this.pictureBox2.Location = new System.Drawing.Point(20, 233);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(108, 82);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::furnitureStoreV2.Properties.Resources.BarakaLogo;
            this.pictureBox1.Location = new System.Drawing.Point(259, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(192, 184);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // FormInterfaceCustumer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(702, 484);
            this.Controls.Add(this.labelCustomerID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.buttonShowMyPreOrders);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.buttonPlaceAnOrder);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormInterfaceCustumer";
            this.Text = "FormInterfaceCustumer";
            this.Load += new System.EventHandler(this.FormInterfaceCustumer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonPlaceAnOrder;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button buttonShowMyPreOrders;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelCustomerID;
    }
}