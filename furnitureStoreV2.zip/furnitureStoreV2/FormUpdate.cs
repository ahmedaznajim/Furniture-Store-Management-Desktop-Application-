﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormUpdate : Form
    {
        int ID;
        string FirstName;
        string LastName;
        string Phone;
        string Email;
        public FormUpdate(int ID,
          string FirstName,
          string LastName, string Phone, string Email)
        {
            InitializeComponent();
            this.ID = ID;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.Phone = Phone;

            textBoxFname.Text = FirstName;
            textBoxLname.Text = LastName;
            textBoxPhone.Text = Phone;
            textBoxEmail.Text = Email;


        }

        private void FormUpdate_Load(object sender, EventArgs e)
        {

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if
            (ClsPersonBuinessLayer.UpdatePerson(ID, FirstName, LastName, Phone, Email))
            {
                MessageBox.Show("Done");

            }
            else
            {
                MessageBox.Show("Faild");


            }
        }
    };
}