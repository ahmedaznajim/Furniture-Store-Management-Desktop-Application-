﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormWarehouse : Form
    {
        public FormWarehouse()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            FormAddWarehouse formAddWarehouse = new FormAddWarehouse();
            formAddWarehouse.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormWarehouse_Load(object sender, EventArgs e)
        {
           dataGridView1.DataSource=  ClsWarehouse.GetAllWarehouse();
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsWarehouse.GetAllWarehouse();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

            if (ClsWarehouse.DeleteWarehouse(Convert.ToInt32(selectedRow.Cells[0].Value)))
            {
                MessageBox.Show("Done");

            }
            else
            {
                MessageBox.Show("Faild");
            }
        }

        private void showProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];


            dataGridView1.DataSource = ClsWarehouse.ShowProducts(Convert.ToInt32(selectedRow.Cells[0].Value));
        }
    }
}
