﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormProduct : Form
    {
        public FormProduct()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            FormAddProduct product = new FormAddProduct();
            product.ShowDialog();
        }

        private void FormProduct_Load(object sender, EventArgs e)
        {
         dataGridView1.DataSource=   ClsProduct.GetAllproducts();
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsProduct.GetAllproducts();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                if (ClsProduct.Deleteproduct(Convert.ToInt32(selectedRow.Cells[0].Value)))
                {
                    MessageBox.Show("Done");

                }
                else
                {
                    MessageBox.Show("Faild");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Select a complete Row");

            }
        }

        private void storeInAWarehouseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

         FormStore f=new FormStore(Convert.ToInt32( selectedRow.Cells[0].Value));
            f.ShowDialog();

            
        }
    }
}
