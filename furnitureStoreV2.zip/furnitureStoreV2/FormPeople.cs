﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;
namespace furnitureStoreV2
{
    public partial class FormPeople : Form
    {
        public FormPeople()
        {
            InitializeComponent();
        }

        private void FormPeople_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource= ClsPersonBuinessLayer.GetAllPeople();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
           FormAddPerson formAddPerson = new FormAddPerson();
            formAddPerson.ShowDialog();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                FormUpdate update = new FormUpdate(
                     Convert.ToInt32(selectedRow.Cells[0].Value),
                    Convert.ToString(selectedRow.Cells[1].Value),  // PersonID
                    Convert.ToString(selectedRow.Cells[2].Value),  // NationalNo
                    Convert.ToString(selectedRow.Cells[3].Value),  // FirstName
                    Convert.ToString(selectedRow.Cells[4].Value)  // SecondName
                   

                );

                update.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a row first.");
            }
        }




            
        

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsPersonBuinessLayer.GetAllPeople();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                if (ClsPersonBuinessLayer.DeletePerson(Convert.ToInt32(selectedRow.Cells[0].Value)))
                {
                    MessageBox.Show("Done");

                }
                else
                {
                    MessageBox.Show("Faild");
                }
            }
            catch
            {
                MessageBox.Show("Select a complete Row");
            }
        }
    }
}
