﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormLogCustomer : Form
    {
        public FormLogCustomer()
        {
            InitializeComponent();
        }

        private void buttonLogIn_Click(object sender, EventArgs e)
        {
            int id = ClsCustmor.CheckCustomerogInInfo(textBoxUserName.Text, textBoxPassword.Text);

            if (id!=-1)
            {
               FormInterfaceCustumer formInterfaceCustumer = new FormInterfaceCustumer(id);
                this.Hide();
                formInterfaceCustumer.ShowDialog();
            

            }else
            {
                MessageBox.Show("Faild");


            }  


        }

        private void label3_Click(object sender, EventArgs e)
        {
            FormSighnUp formSighnUp = new FormSighnUp();
            formSighnUp.ShowDialog();
        }
    }
}
