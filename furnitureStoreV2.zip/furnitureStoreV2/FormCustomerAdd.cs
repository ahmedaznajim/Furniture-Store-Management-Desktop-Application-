﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace furnitureStoreV2
{
    public partial class FormCustomerAdd : Form
    {
        DataTable dt = new DataTable();
        DataRow row1;
        public FormCustomerAdd()
        {
            InitializeComponent();
          
            dt = ClsPersonBuinessLayer.GetAllPeople();

            foreach (DataRow row in dt.Rows)
            {
                comboBox1.Items.Add(row[1].ToString());


            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                row1 = dt.Rows[comboBox1.SelectedIndex];
                if (ClsCustmor.AddNewCustomer(Convert.ToInt32(Convert.ToInt32(row1[0])), Convert.ToString(textBoxUserName.Text), Convert.ToString(textBoxPassword.Text)) == -1)
                {
                    MessageBox.Show("Faild");


                }
                else
                {
                    MessageBox.Show("Done");



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select a Person");


            }


        }

        private void FormCustomerAdd_Load(object sender, EventArgs e)
        {
          
        }
    }
}
